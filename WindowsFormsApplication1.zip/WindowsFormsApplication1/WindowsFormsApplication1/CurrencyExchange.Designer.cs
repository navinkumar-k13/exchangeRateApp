﻿namespace WindowsFormsApplication1
{
    partial class CurrencyExchange
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CurrencyExchange));
            this.getAll = new System.Windows.Forms.Button();
            this.dateLabel = new System.Windows.Forms.Label();
            this.exchangeRateListView = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.exchangeRatesGridView = new System.Windows.Forms.DataGridView();
            this.exportExcelbtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.applicationName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.exchangeRatesGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // getAll
            // 
            this.getAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.getAll.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.getAll.Image = ((System.Drawing.Image)(resources.GetObject("getAll.Image")));
            this.getAll.Location = new System.Drawing.Point(1072, 3);
            this.getAll.Name = "getAll";
            this.getAll.Size = new System.Drawing.Size(56, 45);
            this.getAll.TabIndex = 0;
            this.getAll.UseVisualStyleBackColor = true;
            this.getAll.Click += new System.EventHandler(this.getAll_Click);
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.BackColor = System.Drawing.Color.Transparent;
            this.dateLabel.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateLabel.ForeColor = System.Drawing.Color.White;
            this.dateLabel.Location = new System.Drawing.Point(21, 26);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(59, 22);
            this.dateLabel.TabIndex = 2;
            this.dateLabel.Text = "Date :";
            // 
            // exchangeRateListView
            // 
            this.exchangeRateListView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.exchangeRateListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.exchangeRateListView.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exchangeRateListView.FullRowSelect = true;
            this.exchangeRateListView.GridLines = true;
            this.exchangeRateListView.Location = new System.Drawing.Point(12, 54);
            this.exchangeRateListView.Name = "exchangeRateListView";
            this.exchangeRateListView.Size = new System.Drawing.Size(1240, 591);
            this.exchangeRateListView.TabIndex = 3;
            this.exchangeRateListView.UseCompatibleStateImageBehavior = false;
            this.exchangeRateListView.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Currency Code";
            this.columnHeader1.Width = 617;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Exchange Rates";
            this.columnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.columnHeader2.Width = 617;
            // 
            // exchangeRatesGridView
            // 
            this.exchangeRatesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.exchangeRatesGridView.Location = new System.Drawing.Point(69, 140);
            this.exchangeRatesGridView.Name = "exchangeRatesGridView";
            this.exchangeRatesGridView.Size = new System.Drawing.Size(581, 303);
            this.exchangeRatesGridView.TabIndex = 4;
            this.exchangeRatesGridView.Visible = false;
            // 
            // exportExcelbtn
            // 
            this.exportExcelbtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.exportExcelbtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.exportExcelbtn.Image = ((System.Drawing.Image)(resources.GetObject("exportExcelbtn.Image")));
            this.exportExcelbtn.Location = new System.Drawing.Point(1134, 3);
            this.exportExcelbtn.Name = "exportExcelbtn";
            this.exportExcelbtn.Size = new System.Drawing.Size(56, 45);
            this.exportExcelbtn.TabIndex = 5;
            this.exportExcelbtn.UseVisualStyleBackColor = true;
            this.exportExcelbtn.Click += new System.EventHandler(this.exportExcelbtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.exitBtn.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.exitBtn.Image = ((System.Drawing.Image)(resources.GetObject("exitBtn.Image")));
            this.exitBtn.Location = new System.Drawing.Point(1196, 3);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(56, 45);
            this.exitBtn.TabIndex = 6;
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // applicationName
            // 
            this.applicationName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.applicationName.AutoSize = true;
            this.applicationName.BackColor = System.Drawing.Color.Transparent;
            this.applicationName.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.applicationName.ForeColor = System.Drawing.Color.White;
            this.applicationName.Location = new System.Drawing.Point(557, 24);
            this.applicationName.Name = "applicationName";
            this.applicationName.Size = new System.Drawing.Size(252, 24);
            this.applicationName.TabIndex = 7;
            this.applicationName.Text = "Exchange Rate Application";
            // 
            // CurrencyExchange
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.applicationName);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.exportExcelbtn);
            this.Controls.Add(this.exchangeRateListView);
            this.Controls.Add(this.exchangeRatesGridView);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.getAll);
            this.Name = "CurrencyExchange";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Currency Exchange";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.exchangeRatesGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button getAll;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.ListView exchangeRateListView;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.DataGridView exchangeRatesGridView;
        private System.Windows.Forms.Button exportExcelbtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Label applicationName;
    }
}

