﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;
using System.Globalization;
using Excel = Microsoft.Office.Interop.Excel;
using Newtonsoft.Json;
using System.Runtime.InteropServices;
using System.IO;


namespace WindowsFormsApplication1
{
    public partial class CurrencyExchange : Form
    {
        public static int count;
        class LinkedListNode
        {
        public decimal data;
        public string currencycode;
        public LinkedListNode next;
            public LinkedListNode(string code,decimal x)
        {
            currencycode = code;
            data = x;
            next = null;
        }
        }
        class LinkedList
        {
            LinkedListNode head;
            
            public LinkedList()
            {
                head= null;
                count=0;
            }

            public void AddNodeToFront(string code,decimal data)
            {
                LinkedListNode node = new LinkedListNode(code,data);
                node.next = head;
                head = node;
                count++;
            }            
        }
        public CurrencyExchange()
        {
            InitializeComponent();
        }

        private async void getAll_Click(object sender, EventArgs e)
        {
            var response = await GetApi.GetAll();
            string result = GetApi.BeautifyJSON(response);
            JObject obj = JObject.Parse(result);
            string jsonDate = (string)obj["date"];
            jsonDate = DateTime.ParseExact(jsonDate, "yyyy-mm-dd", CultureInfo.InvariantCulture).ToString("dd/mm/yyyy");
            dateLabel.Text = "Date : " + jsonDate;
            var dict = JObject.Parse(result).SelectToken("aud").ToObject<Dictionary<string, decimal>>();
            LinkedList linklist = new LinkedList();
            string[] exchangeRateItems = new string[2];
            ListViewItem itm = new ListViewItem();
            foreach (var kv in dict)
            {
                linklist.AddNodeToFront(kv.Key,kv.Value);
                string[] data = (kv.Key + ":" + kv.Value).ToString().Split(':');
                exchangeRateItems[0] = data[0].ToString();
                exchangeRateItems[1] = data[1].ToString();
                itm = new ListViewItem(exchangeRateItems);
                exchangeRateListView.Items.Add(itm);
           }

            var listView1 = new ListView();
            DataTable table = new DataTable();
            foreach (ColumnHeader header in exchangeRateListView.Columns)
            {
                table.Columns.Add(header.Text.ToString());
            }
            object[] listValues = new object[table.Columns.Count];
            foreach (ListViewItem item in exchangeRateListView.Items)
            {
                int i = 0;
                for (int j = 0; j < table.Columns.Count; j++)
                {
                    listValues[i] = item.SubItems[j].Text;
                    i++;
                }
                table.Rows.Add(listValues);
            }
            exchangeRatesGridView.DataSource = table;
            exchangeRatesGridView.AllowUserToAddRows = false;
            string temp, dummy;
            for (int i = 0; i < exchangeRatesGridView.RowCount; i++)
            {
                for (int j = 0; j < exchangeRatesGridView.RowCount - 1; j++)
                {
                    if (Convert.ToDecimal(exchangeRatesGridView[1, j].Value.ToString()) < Convert.ToDecimal(exchangeRatesGridView[1, j + 1].Value.ToString()))
                    {

                        temp = exchangeRatesGridView[1, j].Value.ToString();
                        exchangeRatesGridView[1, j].Value = exchangeRatesGridView[1, j + 1].Value.ToString();
                        exchangeRatesGridView[1, j + 1].Value = temp;
                        dummy = exchangeRatesGridView[0, j].Value.ToString();
                        exchangeRatesGridView[0, j].Value = exchangeRatesGridView[0, j + 1].Value.ToString();
                        exchangeRatesGridView[0, j + 1].Value = dummy;
                    }
                }
            }
            exchangeRateListView.Items.Clear();
            for(int i=0;i<exchangeRatesGridView.RowCount;i++)
            {
                exchangeRateItems[0] = exchangeRatesGridView[0, i].Value.ToString();
                exchangeRateItems[1] = exchangeRatesGridView[1, i].Value.ToString();
                itm = new ListViewItem(exchangeRateItems);
                exchangeRateListView.Items.Add(itm);
            }          
        }

        private async void exportExcelbtn_Click(object sender, EventArgs e)
        {
            try
            {
                using (SaveFileDialog saveFile = new SaveFileDialog() { Filter = "CSV|*.csv", ValidateNames = true })
                {
                    if (saveFile.ShowDialog() == DialogResult.OK)
                    {
                        using (StreamWriter sw = new StreamWriter(new FileStream(saveFile.FileName, FileMode.Create), Encoding.UTF8))
                        {
                            StringBuilder stringBuilder = new StringBuilder();
                            stringBuilder.AppendLine("Currency Code,Exchange Rates");
                            foreach (ListViewItem item in exchangeRateListView.Items)
                            {
                                stringBuilder.AppendLine(string.Format("{0},{1}", item.SubItems[0].Text, item.SubItems[1].Text));
                            }
                            await sw.WriteLineAsync(stringBuilder.ToString());
                            MessageBox.Show("Your data has been successfully exported", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception exe)
            {
                MessageBox.Show("File Export Issue");
                Console.WriteLine(exe.ToString());

            }
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
